# OS Laboratory Practicals

Study collection organized by the official PICT OSL assignment index.

Read [START_HERE.txt](START_HERE.txt) for assignment coverage, build commands,
remaining gaps and known issues. The included PDF is the official assignment
index, not a full lab manual.

- `Today_Uploads` and `Today_Paste`: supplied source files, unchanged.
- `Original_References` and `Additional_Originals`: recovered originals.
- `07_Page_Replacement/Corrected_A7`: input-based version with runtime tests.

All eight assignments have relevant material. This does not mean every
requirement is complete or every program is correct. A1's 20-command demo and
A6's explicit fixed-partition/non-contiguous allocation remain unlocated.

Original sources remain separate from the A7 correction. No other code fixes
were made. C++ is allowed. See the A7 test report.
